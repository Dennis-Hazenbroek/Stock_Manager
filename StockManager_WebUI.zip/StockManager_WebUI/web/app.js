"use strict";

const state = { data: null, view: "overview", search: "" };
const content = document.querySelector("#page-content");
const dialog = document.querySelector("#action-dialog");
const dialogContent = document.querySelector("#dialog-content");
const toast = document.querySelector("#toast");
let toastTimer;

const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
}[character]));

async function request(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  const type = response.headers.get("content-type") || "";
  if (!response.ok) {
    const result = type.includes("application/json") ? await response.json() : {};
    throw new Error(result.error || `Request failed (${response.status}).`);
  }
  return type.includes("application/json") ? response.json() : response;
}

async function refresh(message) {
  try {
    state.data = await request("/api/data");
    render();
    if (message) notify(message);
  } catch (error) {
    content.innerHTML = `<section class="panel empty-state"><strong>Could not load your workspace</strong>${escapeHtml(error.message)}</section>`;
    notify(error.message, true);
  }
}

function notify(message, isError = false) {
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

function money(value) {
  return `${escapeHtml(state.data.currency_symbol)}${Number(value || 0).toLocaleString(undefined, {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  })}`;
}

function dateLabel(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? escapeHtml(value) : date.toLocaleDateString(undefined, {
    day: "numeric", month: "short", year: "numeric",
  });
}

function supplierName(id) {
  return state.data.suppliers.find((supplier) => supplier.id === id)?.company || "Unassigned";
}

function statusBadge(status) {
  const key = String(status || "").toLowerCase();
  return `<span class="badge ${escapeHtml(key)}">${escapeHtml(status || "Unknown")}</span>`;
}

function heading(kicker, title, description, actions = "") {
  return `<div class="page-heading"><div><div class="eyebrow">${kicker}</div><h1>${title}</h1><p>${description}</p></div><div class="heading-actions">${actions}</div></div>`;
}

function itemMatches(item) {
  const query = state.search.trim().toLowerCase();
  return !query || [item.id, item.name, item.description, item.category, supplierName(item.supplier_id)]
    .some((value) => String(value || "").toLowerCase().includes(query));
}

function productCell(item) {
  const initial = escapeHtml((item.name || "?").trim().charAt(0).toUpperCase());
  return `<div class="product-cell"><span class="product-thumb">${initial}</span><span><span class="product-name">${escapeHtml(item.name)}</span><span class="product-id">${escapeHtml(item.id)}</span></span></div>`;
}

function inventoryRows(items, actions = false) {
  if (!items.length) return `<tr><td colspan="${actions ? 7 : 6}"><div class="empty-state"><strong>No products found</strong>Try a different search or add your first item.</div></td></tr>`;
  return items.map((item) => {
    const low = Number(item.quantity) <= Number(item.minimum);
    const level = Math.min(100, Math.round(Number(item.quantity) / Math.max(1, Number(item.minimum) * 2) * 100));
    return `<tr>
      <td>${productCell(item)}</td><td>${escapeHtml(item.category || "—")}</td>
      <td><div class="inventory-level"><span>${escapeHtml(item.quantity)}</span><span class="level-track"><span class="level-fill ${low ? "low" : ""}" style="display:block;width:${level}%"></span></span></div></td>
      <td>${escapeHtml(item.minimum)}</td><td>${money(item.unit_cost)}</td>
      <td><span class="badge ${low ? "low" : ""}">${low ? "Low stock" : "In stock"}</span></td>
      ${actions ? `<td><div class="table-actions"><button class="button button-quiet" data-action="adjust" data-id="${escapeHtml(item.id)}" aria-label="Adjust stock">± Stock</button><button class="button button-quiet" data-action="edit-item" data-id="${escapeHtml(item.id)}" aria-label="Edit item">Edit</button><button class="button button-quiet" data-action="delete-item" data-id="${escapeHtml(item.id)}" aria-label="Delete item">···</button></div></td>` : ""}
    </tr>`;
  }).join("");
}

function inventoryTable(items, actions = false) {
  return `<div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Available</th><th>Min. level</th><th>Unit cost</th><th>Status</th>${actions ? "<th>Actions</th>" : ""}</tr></thead><tbody>${inventoryRows(items, actions)}</tbody></table></div>`;
}

function statCard(label, value, note, icon, attention = false) {
  return `<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot ${attention ? "attention" : ""}">${note}</div></article>`;
}

function recentMovementRows(movements) {
  if (!movements.length) return `<div class="empty-state"><strong>No stock activity yet</strong>Stock adjustments will show up here.</div>`;
  return `<div class="table-wrap"><table><thead><tr><th>Product</th><th>Movement</th><th>Quantity</th><th>Date</th></tr></thead><tbody>${movements.slice(0, 5).map((move) => `<tr><td>${productCell({ id: move.item_id, name: move.item_name })}</td><td>${escapeHtml(move.type)}</td><td><span class="movement-sign ${move.type === "OUT" ? "out" : "in"}">${move.type === "OUT" ? "−" : "+"}${escapeHtml(move.quantity)}</span></td><td>${dateLabel(move.timestamp)}</td></tr>`).join("")}</tbody></table></div>`;
}

function categoryChart() {
  const counts = new Map();
  state.data.stock.forEach((item) => {
    const key = item.category || "Uncategorized";
    counts.set(key, (counts.get(key) || 0) + 1);
  });
  const values = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  if (!values.length) return `<div class="empty-state">Add products to see category breakdown.</div>`;
  const highest = Math.max(...values.map((entry) => entry[1]));
  return `<div class="chart-list">${values.map(([name, count]) => `<div class="chart-row"><span>${escapeHtml(name)}</span><span class="chart-track"><span class="chart-bar" style="display:block;width:${Math.round(count / highest * 100)}%"></span></span><span class="chart-count">${count}</span></div>`).join("")}</div>`;
}

function overview() {
  const { summary, stock, movements, orders } = state.data;
  const low = stock.filter((item) => Number(item.quantity) <= Number(item.minimum));
  const newestOrders = [...orders].sort((a, b) => String(b.created_at || "").localeCompare(a.created_at || "")).slice(0, 4);
  content.innerHTML = `
    ${heading(new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" }).toUpperCase(), "Good to see you.", "Here’s what’s happening with your inventory today.", '<button class="button button-secondary" data-action="export-menu">↓ Export CSV</button><button class="button button-primary" data-action="add-item">＋ Add new item</button>')}
    <section class="stats-grid">
      ${statCard("Total products", summary.item_count, "Product lines in your inventory", "▤")}
      ${statCard("Units in stock", Number(summary.total_units).toLocaleString(), "Across all product lines", "◫")}
      ${statCard("Inventory value", money(summary.inventory_value), "At current unit cost", "£")}
      ${statCard("Needs attention", summary.low_stock_count, summary.low_stock_count ? "Items at or below minimum" : "All stock levels look good", "!", summary.low_stock_count > 0)}
    </section>
    <section class="content-grid">
      <article class="panel">
        <div class="panel-header"><div><h2 class="panel-title">Inventory overview</h2><p class="panel-subtitle">A quick look at your current stock levels</p></div><button class="text-button" data-view="inventory">View inventory →</button></div>
        ${inventoryTable([...stock].sort((a, b) => (a.quantity <= a.minimum ? -1 : 0) - (b.quantity <= b.minimum ? -1 : 0)).slice(0, 5))}
        <div class="panel-footer"><span>Showing ${Math.min(5, stock.length)} of ${stock.length} products</span><span>Updated just now</span></div>
      </article>
      <article class="panel">
        <div class="panel-header"><div><h2 class="panel-title">Low stock alerts</h2><p class="panel-subtitle">Products at or below their minimum</p></div><span class="badge ${low.length ? "low" : ""}">${low.length} items</span></div>
        <div class="alert-list">${low.length ? low.slice(0, 5).map((item) => `<div class="alert-item"><span class="alert-dot"></span><span><span class="alert-name">${escapeHtml(item.name)}</span><span class="alert-meta">${escapeHtml(item.id)} · Min. ${escapeHtml(item.minimum)}</span></span><span class="alert-qty">${escapeHtml(item.quantity)} left</span></div>`).join("") : `<div class="empty-state"><strong>You’re all stocked up</strong>No products need reordering right now.</div>`}</div>
        ${low.length ? `<div class="panel-footer"><button class="text-button" data-view="inventory">Review low stock →</button><button class="text-button" data-action="create-orders">Create purchase orders</button></div>` : ""}
      </article>
    </section>
    <section class="content-grid section-spacer">
      <article class="panel"><div class="panel-header"><div><h2 class="panel-title">Recent stock movements</h2><p class="panel-subtitle">Latest inventory activity</p></div><button class="text-button" data-view="movements">See all →</button></div>${recentMovementRows(movements)}</article>
      <article class="panel"><div class="panel-header"><div><h2 class="panel-title">Products by category</h2><p class="panel-subtitle">Product line distribution</p></div></div>${categoryChart()}</article>
    </section>
    <section class="panel section-spacer"><div class="panel-header"><div><h2 class="panel-title">Purchase orders</h2><p class="panel-subtitle">Your latest supplier orders</p></div><button class="text-button" data-view="orders">All orders →</button></div>${orderTable(newestOrders, false)}</section>`;
}

function inventoryView() {
  const items = state.data.stock.filter((item) => {
    if (!itemMatches(item)) return false;
    if (state.stockFilter === "low") return Number(item.quantity) <= Number(item.minimum);
    if (state.stockFilter === "available") return Number(item.quantity) > Number(item.minimum);
    return true;
  });
  content.innerHTML = `${heading("STOCK CONTROL", "Inventory", `${state.data.stock.length} product lines across your stockroom.`, '<button class="button button-secondary" data-action="export" data-report="inventory">↓ Export</button><button class="button button-primary" data-action="add-item">＋ Add item</button>')}
    <section class="panel"><div class="filter-row"><input class="filter-input" id="inventory-filter" type="search" placeholder="Filter products..." value="${escapeHtml(state.search)}"><select class="filter-select" id="stock-filter"><option value="all">All stock</option><option value="low">Low stock only</option><option value="available">In stock</option></select><span class="stat-foot">${items.length} results</span></div>${inventoryTable(items, true)}</section>`;
  const select = document.querySelector("#stock-filter");
  select.value = state.stockFilter || "all";
  select.addEventListener("change", () => { state.stockFilter = select.value; render(); });
  const filter = document.querySelector("#inventory-filter");
  filter.addEventListener("input", () => { state.search = filter.value; const cursor = filter.selectionStart; render(); const updated = document.querySelector("#inventory-filter"); updated.focus(); updated.setSelectionRange(cursor, cursor); });
}

function supplierView() {
  const suppliers = state.data.suppliers.filter((supplier) =>
    !state.search || [supplier.id, supplier.company, supplier.contact, supplier.email].join(" ").toLowerCase().includes(state.search.toLowerCase()));
  const rows = suppliers.length ? suppliers.map((supplier) => {
    const suppliedItems = state.data.stock.filter((item) => item.supplier_id === supplier.id).length;
    return `<tr><td><div class="product-cell"><span class="product-thumb">${escapeHtml((supplier.company || "?").charAt(0).toUpperCase())}</span><span><span class="product-name">${escapeHtml(supplier.company)}</span><span class="product-id">${escapeHtml(supplier.id)}</span></span></div></td><td>${escapeHtml(supplier.contact || "—")}</td><td>${supplier.email ? `<a href="mailto:${escapeHtml(supplier.email)}">${escapeHtml(supplier.email)}</a>` : "—"}</td><td>${escapeHtml(supplier.phone || "—")}</td><td>${suppliedItems} products</td><td><div class="table-actions"><button class="button button-quiet" data-action="edit-supplier" data-id="${escapeHtml(supplier.id)}">Edit</button><button class="button button-quiet" data-action="delete-supplier" data-id="${escapeHtml(supplier.id)}">···</button></div></td></tr>`;
  }).join("") : `<tr><td colspan="6"><div class="empty-state"><strong>No suppliers found</strong>Add a supplier to connect products and purchase orders.</div></td></tr>`;
  content.innerHTML = `${heading("PARTNERS", "Suppliers", `${state.data.suppliers.length} supplier${state.data.suppliers.length === 1 ? "" : "s"} in your directory.`, '<button class="button button-primary" data-action="add-supplier">＋ Add supplier</button>')}
    <section class="panel"><div class="filter-row"><input class="filter-input" id="supplier-filter" type="search" placeholder="Search suppliers..." value="${escapeHtml(state.search)}"><span class="stat-foot">${suppliers.length} results</span></div><div class="table-wrap"><table><thead><tr><th>Supplier</th><th>Contact</th><th>Email</th><th>Phone</th><th>Products</th><th>Actions</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
  document.querySelector("#supplier-filter").addEventListener("input", (event) => {
    state.search = event.target.value;
    const cursor = event.target.selectionStart;
    render();
    const updated = document.querySelector("#supplier-filter");
    updated.focus(); updated.setSelectionRange(cursor, cursor);
  });
}

function orderTable(orders, actions = true) {
  if (!orders.length) return `<div class="empty-state"><strong>No purchase orders yet</strong>Create orders from low-stock products to get started.</div>`;
  const rows = orders.map((order) => {
    const canSend = order.status === "DRAFT";
    const canReceive = order.status === "SENT";
    return `<tr><td><strong>${escapeHtml(order.id)}</strong><span class="product-id">${dateLabel(order.created_at)}</span></td><td>${escapeHtml(supplierName(order.supplier_id))}</td><td>${(order.items || []).length} items</td><td>${money(order.total)}</td><td>${statusBadge(order.status)}</td>${actions ? `<td><div class="table-actions">${canSend ? `<button class="button button-quiet" data-action="email-order" data-id="${escapeHtml(order.id)}">Review &amp; email</button><button class="button button-quiet" data-action="send-order" data-id="${escapeHtml(order.id)}">Mark sent</button><button class="button button-quiet" data-action="cancel-order" data-id="${escapeHtml(order.id)}">Cancel</button>` : ""}${canReceive ? `<button class="button button-quiet" data-action="receive-order" data-id="${escapeHtml(order.id)}">Receive</button>` : ""}</div></td>` : ""}</tr>`;
  }).join("");
  return `<div class="table-wrap"><table><thead><tr><th>Order</th><th>Supplier</th><th>Items</th><th>Total</th><th>Status</th>${actions ? "<th>Actions</th>" : ""}</tr></thead><tbody>${rows}</tbody></table></div>`;
}

function ordersView() {
  const orders = [...state.data.orders].sort((a, b) => String(b.created_at || "").localeCompare(a.created_at || ""));
  content.innerHTML = `${heading("REPLENISHMENT", "Purchase orders", `${state.data.summary.open_order_count} open order${state.data.summary.open_order_count === 1 ? "" : "s"} need tracking.`, '<button class="button button-secondary" data-action="email-settings">Email settings</button><button class="button button-secondary" data-action="export" data-report="orders">↓ Export</button><button class="button button-primary" data-action="create-orders">＋ Create from low stock</button>')}
    <section class="panel"><div class="filter-row"><span class="stat-foot">Orders are grouped by supplier; receive an order to update stock levels.</span></div>${orderTable(orders)}</section>`;
}

function movementsView() {
  const movements = state.data.movements.filter((move) => !state.search || [move.item_name, move.item_id, move.type, move.reference].join(" ").toLowerCase().includes(state.search.toLowerCase()));
  const rows = movements.length ? movements.map((move) => `<tr><td>${productCell({ id: move.item_id, name: move.item_name })}</td><td>${escapeHtml(move.type)}</td><td><span class="movement-sign ${move.type === "OUT" ? "out" : "in"}">${move.type === "OUT" ? "−" : "+"}${escapeHtml(move.quantity)}</span></td><td>${escapeHtml(move.balance_after)}</td><td>${escapeHtml(move.reference || "—")}</td><td>${dateLabel(move.timestamp)}</td></tr>`).join("") : `<tr><td colspan="6"><div class="empty-state"><strong>No movements found</strong>New stock activity will appear here.</div></td></tr>`;
  content.innerHTML = `${heading("AUDIT TRAIL", "Stock movements", `Showing the latest ${state.data.movements.length} stock transactions.`, '<button class="button button-secondary" data-action="export" data-report="movements">↓ Export CSV</button>')}
    <section class="panel"><div class="filter-row"><input class="filter-input" id="movement-filter" type="search" placeholder="Search movements..." value="${escapeHtml(state.search)}"><span class="stat-foot">${movements.length} movements</span></div><div class="table-wrap"><table><thead><tr><th>Product</th><th>Type</th><th>Quantity</th><th>Balance after</th><th>Reference</th><th>Date</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
  document.querySelector("#movement-filter").addEventListener("input", (event) => {
    state.search = event.target.value;
    const cursor = event.target.selectionStart;
    render();
    const updated = document.querySelector("#movement-filter");
    updated.focus(); updated.setSelectionRange(cursor, cursor);
  });
}

function render() {
  if (!state.data) return;
  const names = { overview: "Overview", inventory: "Inventory", suppliers: "Suppliers", orders: "Purchase orders", movements: "Stock movements" };
  document.querySelector("#breadcrumb-current").textContent = names[state.view];
  document.querySelectorAll(".nav-link").forEach((link) => link.classList.toggle("active", link.dataset.view === state.view));
  ({ overview, inventory: inventoryView, suppliers: supplierView, orders: ordersView, movements: movementsView }[state.view] || overview)();
}

function openDialog(title, subtitle, fields, submitLabel, onSubmit, successMessage = "Changes saved.") {
  dialogContent.innerHTML = `<div class="dialog-header"><div><h2>${title}</h2><p>${subtitle}</p></div><button class="icon-button" type="button" data-action="close-dialog" aria-label="Close dialog">×</button></div><form class="dialog-form"><div class="form-grid">${fields}</div><div class="dialog-actions"><button type="button" class="button button-secondary" data-action="close-dialog">Cancel</button><button type="submit" class="button button-primary">${submitLabel}</button></div></form>`;
  dialog.showModal();
  dialogContent.querySelector("form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.currentTarget.querySelector('[type="submit"]');
    button.disabled = true;
    try {
      await onSubmit(new FormData(event.currentTarget));
      dialog.close();
      await refresh(successMessage);
    } catch (error) {
      notify(error.message, true);
      button.disabled = false;
    }
  });
}

function textField(name, label, value = "", options = {}) {
  const type = options.type || "text";
  const required = options.required ? "required" : "";
  const min = options.min !== undefined ? `min="${options.min}"` : "";
  const step = options.step ? `step="${options.step}"` : "";
  const placeholder = options.placeholder ? `placeholder="${escapeHtml(options.placeholder)}"` : "";
  return `<div class="form-field ${options.full ? "full" : ""}"><label for="field-${name}">${label}${options.required ? " *" : ""}</label><input id="field-${name}" name="${name}" type="${type}" value="${escapeHtml(value)}" ${required} ${min} ${step} ${placeholder}></div>`;
}

function selectField(name, label, selected = "", includeBlank = true) {
  const blank = includeBlank ? '<option value="">Unassigned</option>' : "";
  const options = state.data.suppliers.map((supplier) => `<option value="${escapeHtml(supplier.id)}" ${supplier.id === selected ? "selected" : ""}>${escapeHtml(supplier.company)} (${escapeHtml(supplier.id)})</option>`).join("");
  return `<div class="form-field"><label for="field-${name}">${label}</label><select id="field-${name}" name="${name}">${blank}${options}</select></div>`;
}

function showItemDialog(item) {
  const fields = [
    textField("id", "Product ID / SKU", item?.id || "", { required: true }),
    textField("name", "Product name", item?.name || "", { required: true }),
    textField("category", "Category", item?.category || ""),
    selectField("supplier_id", "Supplier", item?.supplier_id || ""),
    textField("quantity", "Opening quantity", item?.quantity ?? 0, { type: "number", min: 0 }),
    textField("minimum", "Minimum stock", item?.minimum ?? 0, { type: "number", min: 0 }),
    textField("reorder_quantity", "Reorder quantity", item?.reorder_quantity ?? 1, { type: "number", min: 1 }),
    textField("unit_cost", "Unit cost", item?.unit_cost ?? 0, { type: "number", min: 0, step: "0.01" }),
    `<div class="form-field full"><label for="field-description">Description</label><textarea id="field-description" name="description">${escapeHtml(item?.description || "")}</textarea></div>`,
  ].join("");
  openDialog(item ? "Edit product" : "Add a product", item ? "Update product details and reorder settings." : "Add a new product to your inventory.", fields, item ? "Save changes" : "Add product", async (form) => {
    const values = Object.fromEntries(form.entries());
    if (item) {
      delete values.id;
      delete values.quantity;
      await request(`/api/stock/${encodeURIComponent(item.id)}`, { method: "PUT", body: JSON.stringify(values) });
    } else {
      await request("/api/stock", { method: "POST", body: JSON.stringify(values) });
    }
  });
}

function showSupplierDialog(supplier) {
  const fields = [
    textField("id", "Supplier ID", supplier?.id || "", { required: true }),
    textField("company", "Company name", supplier?.company || "", { required: true }),
    textField("contact", "Contact person", supplier?.contact || ""),
    textField("email", "Email address", supplier?.email || "", { type: "email" }),
    textField("phone", "Telephone", supplier?.phone || ""),
    textField("address", "Address", supplier?.address || ""),
  ].join("");
  openDialog(supplier ? "Edit supplier" : "Add a supplier", "Supplier details are used when preparing purchase orders.", fields, supplier ? "Save changes" : "Add supplier", async (form) => {
    const values = Object.fromEntries(form.entries());
    if (supplier) {
      delete values.id;
      await request(`/api/suppliers/${encodeURIComponent(supplier.id)}`, { method: "PUT", body: JSON.stringify(values) });
    } else {
      await request("/api/suppliers", { method: "POST", body: JSON.stringify(values) });
    }
  });
}

function showAdjustmentDialog(item) {
  const fields = `<div class="form-field"><label for="field-direction">Transaction</label><select id="field-direction" name="direction"><option value="IN">Stock in</option><option value="OUT">Stock out</option></select></div>${textField("quantity", "Quantity", 1, { type: "number", min: 1, required: true })}${textField("reference", "Reference / reason", "", { full: true, placeholder: "e.g. delivery, sale, correction" })}<div class="form-field full"><span class="stat-foot">Currently available: ${escapeHtml(item.quantity)} units</span></div>`;
  openDialog("Adjust stock", `${item.name} · ${item.id}`, fields, "Record movement", async (form) => {
    const values = Object.fromEntries(form.entries());
    values.item_id = item.id;
    values.quantity = Number(values.quantity);
    await request("/api/transactions", { method: "POST", body: JSON.stringify(values) });
  });
}

function showExportDialog() {
  const fields = `<div class="form-field full"><label for="field-report">Report type</label><select id="field-report" name="report"><option value="inventory">Complete inventory</option><option value="suppliers">Supplier list</option><option value="low_stock">Low-stock items</option><option value="movements">Stock movement history</option><option value="orders">Purchase order history</option></select></div>`;
  openDialog("Export a report", "Download a CSV file for a spreadsheet or audit.", fields, "Download CSV", async (form) => {
    await exportReport(form.get("report"), false);
  }, "CSV report exported.");
}

async function showEmailSettingsDialog() {
  try {
    const settings = await request("/api/email-settings");
    const fields = [
      textField("smtp_host", "SMTP server / host", settings.smtp_host, { required: true }),
      textField("smtp_port", "SMTP port", settings.smtp_port, { type: "number", min: 1, required: true }),
      textField("sender", "Sender email address", settings.sender, { type: "email", required: true }),
      textField("username", "SMTP username", settings.username, { required: true }),
      textField("password_env", "Password environment variable", settings.password_env, { required: true, full: true }),
      `<div class="form-field full"><label for="field-use_starttls">Connection security</label><select id="field-use_starttls" name="use_starttls"><option value="true" ${settings.use_starttls ? "selected" : ""}>Use STARTTLS</option><option value="false" ${settings.use_starttls ? "" : "selected"}>No STARTTLS</option></select><span class="stat-foot">${settings.password_configured ? "SMTP password is available in the server environment." : "SMTP password is not set in the server environment."}</span></div>`,
      `<div class="form-field full"><span class="stat-foot">The password is never entered or stored here. Set it in the server environment as “${escapeHtml(settings.password_env)}”.</span></div>`,
    ].join("");
    openDialog("Email settings", "Configure the SMTP account used to email purchase orders.", fields, "Save settings", async (form) => {
      const values = Object.fromEntries(form.entries());
      values.smtp_port = Number(values.smtp_port);
      values.use_starttls = values.use_starttls === "true";
      await request("/api/email-settings", { method: "PUT", body: JSON.stringify(values) });
    }, "Email settings saved.");
  } catch (error) {
    notify(error.message, true);
  }
}

async function showOrderEmailDialog(order) {
  try {
    const preview = await request(`/api/orders/${encodeURIComponent(order.id)}/email-preview`);
    const fields = `
      <div class="form-field full"><label for="email-to">To</label><input id="email-to" value="${escapeHtml(preview.to)}" readonly></div>
      <div class="form-field full"><label for="email-from">From</label><input id="email-from" value="${escapeHtml(preview.from)}" readonly></div>
      <div class="form-field full"><label for="email-subject">Subject</label><input id="email-subject" value="${escapeHtml(preview.subject)}" readonly></div>
      <div class="form-field full"><label for="email-body">Message</label><textarea id="email-body" class="email-preview-body" readonly>${escapeHtml(preview.body)}</textarea></div>
      <div class="form-field full"><span class="stat-foot">Sending this email will mark ${escapeHtml(order.id)} as SENT.</span></div>`;
    openDialog("Review supplier email", `${escapeHtml(order.id)} · ${escapeHtml(supplierName(order.supplier_id))}`, fields, "Send email", async () => {
      await request(`/api/orders/${encodeURIComponent(order.id)}/email`, {
        method: "POST",
        body: "{}",
      });
    }, `${order.id} emailed and marked as sent.`);
  } catch (error) {
    notify(error.message, true);
  }
}

async function exportReport(report, showMessage = true) {
  const response = await fetch(`/api/export/${encodeURIComponent(report)}`);
  if (!response.ok) {
    const result = await response.json();
    throw new Error(result.error || "Could not export report.");
  }
  const blob = await response.blob();
  const disposition = response.headers.get("Content-Disposition") || "";
  const filename = disposition.match(/filename="([^"]+)"/)?.[1] || `${report}.csv`;
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
  if (showMessage) notify("CSV report exported.");
}

async function handleAction(action, id, element) {
  const item = state.data.stock.find((record) => record.id === id);
  const supplier = state.data.suppliers.find((record) => record.id === id);
  const order = state.data.orders.find((record) => record.id === id);
  if (action === "add-item") return showItemDialog();
  if (action === "edit-item") return showItemDialog(item);
  if (action === "adjust") return showAdjustmentDialog(item);
  if (action === "add-supplier") return showSupplierDialog();
  if (action === "edit-supplier") return showSupplierDialog(supplier);
  if (action === "email-settings") return showEmailSettingsDialog();
  if (action === "email-order") return showOrderEmailDialog(order);
  if (action === "export") {
    try { await exportReport(element.dataset.report); } catch (error) { notify(error.message, true); }
    return;
  }
  if (action === "export-menu") {
    return showExportDialog();
  }
  if (action === "create-orders") {
    try {
      const result = await request("/api/orders/low-stock", { method: "POST", body: "{}" });
      await refresh(result.message);
    } catch (error) { notify(error.message, true); }
    return;
  }
  if (action === "delete-item" && window.confirm(`Delete ${item.name} (${item.id})? Historical movements will be kept.`)) {
    try {
      const result = await request(`/api/stock/${encodeURIComponent(id)}`, { method: "DELETE" });
      await refresh(result.message);
    } catch (error) { notify(error.message, true); }
    return;
  }
  if (action === "delete-supplier" && window.confirm(`Delete supplier ${supplier.company}?`)) {
    try {
      const result = await request(`/api/suppliers/${encodeURIComponent(id)}`, { method: "DELETE" });
      await refresh(result.message);
    } catch (error) { notify(error.message, true); }
    return;
  }
  const orderActions = {
    "send-order": { path: "sent", prompt: `Mark ${id} as sent to the supplier?` },
    "receive-order": { path: "receive", prompt: `Confirm the full order ${id} has arrived? Stock levels will be updated.` },
    "cancel-order": { path: "cancel", prompt: `Cancel draft ${id}?` },
  };
  if (orderActions[action]) {
    const detail = orderActions[action];
    if (!window.confirm(detail.prompt)) return;
    try {
      const result = await request(`/api/orders/${encodeURIComponent(order.id)}/${detail.path}`, { method: "POST", body: "{}" });
      await refresh(result.message);
    } catch (error) { notify(error.message, true); }
  }
}

document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-view], [data-action]");
  if (!button) return;
  if (button.dataset.view) {
    state.view = button.dataset.view;
    state.search = "";
    render();
    return;
  }
  if (button.dataset.action === "close-dialog") {
    dialog.close();
    return;
  }
  handleAction(button.dataset.action, button.dataset.id, button);
});

document.querySelector("#top-add-item").addEventListener("click", () => showItemDialog());
document.querySelector("#global-search").addEventListener("input", (event) => {
  state.search = event.target.value;
  if (state.view === "overview") state.view = "inventory";
  render();
  const input = document.querySelector("#global-search");
  input.focus();
  input.setSelectionRange(state.search.length, state.search.length);
});
document.addEventListener("keydown", (event) => {
  if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName)) {
    event.preventDefault();
    document.querySelector("#global-search").focus();
  }
});
dialog.addEventListener("click", (event) => {
  if (event.target === dialog) dialog.close();
});

refresh();
